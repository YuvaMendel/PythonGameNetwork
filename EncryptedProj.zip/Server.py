import User
import socket
import threading
import pickle
import tcp
import smtplib
import ssl
from email.message import EmailMessage
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5 as Cipher_PKCS1_v1_5
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import dh
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat, load_der_public_key
from cryptography.hazmat.backends import default_backend


# protocol opcodes
LOGIN_OPCODE = b'LOGN'
SIGNUP_OPCODE = b'SNUP'
ERROR_OPCODE = b'EROR'
ACKNOWLEDGE_LOGIN_OPCODE = b'ACKL'
ACKNOWLEDGE_SIGNUP_OPCODE = b'ACKS'
VERIFY_OPCODE = b'VRFY'
ACKNOWLEDGE_VERIFY_OPCODE = b'ACKV'
FORGOT_PASSWORD_OPCODE = b'FGPW'
FORGOT_PASSWORD_ACK = b'ACKP'
FORGOT_PASSWORD_VERIFY_OPCODE = b'FPWV'

# Error Codes
LOGIN_FAILED = b'001'
SIGNUP_FAILED = b'002'
UNCLEAR_INSTRUCTION = b'003'
VERIFICATION_FAILED = b'004'
FORGOT_PASSWORD_FAILED = b'005'
FORGOT_PASSWORD_VERIFY_FAILED = b'006'

P = 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF
G = 2

SERVER_EMAIL = "mendelyuval9@gmail.com"
EMAIL_PASSWORD = 'eQcgeQegIAawYQdAeQIAcwaweQdAIAYgZgawdw'


user_dict_LOCK = threading.Lock()


def send_msg_to_email(email_to_send, subject, msg):
    em = EmailMessage()
    em['From'] = SERVER_EMAIL
    em['To'] = email_to_send
    em['Subject'] = subject
    em.set_content(msg)
    context = ssl.create_default_context()

    with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
        email_password = ''.join([base64.b64decode(e).decode() for e in
                                 [EMAIL_PASSWORD[i:i + 2] + '==' for i in range(0, len(EMAIL_PASSWORD), 2)]])
        smtp.login(SERVER_EMAIL, email_password)
        smtp.sendmail(SERVER_EMAIL, email_to_send, em.as_string())


def login(client_user):
    if not User.is_user_exist(client_user):
        raise Exception("User does not exist")


def signup(client_user):
    global user_dict_LOCK
    with user_dict_LOCK:
        if User.can_save_user(client_user):
            return User.save_user(client_user)
        else:
            raise Exception("User can not be saved")


def verify(user, code):
    global user_dict_LOCK
    with user_dict_LOCK as lck:
        if User.verify(user, code):
            pass
        else:
            raise Exception()


def forgot_pw(username):
    global user_dict_LOCK
    with user_dict_LOCK as lck:
        return User.forgot_pw_sign(username)


def forgot_pw_verify(username, code):
    global user_dict_LOCK
    with user_dict_LOCK as lck:
        return User.verify_fpw(username, code)


def handle_data(data):
    opcode = data[:4]
    rdata = data[4:]
    if opcode == LOGIN_OPCODE:
        try:
            cli_user = pickle.loads(rdata)
            login(cli_user)
            to_send = ACKNOWLEDGE_LOGIN_OPCODE
        except:
            to_send = ERROR_OPCODE + LOGIN_FAILED
    elif opcode == SIGNUP_OPCODE:
        try:
            cli_user = pickle.loads(rdata)
            user, verification = signup(cli_user)
            send_msg_to_email(user.email, "Verification code", "Verification code is: " + verification.verify_code)
            to_send = ACKNOWLEDGE_SIGNUP_OPCODE

        except:
            to_send = ERROR_OPCODE + SIGNUP_FAILED
    elif opcode == VERIFY_OPCODE:
        try:
            user_code_tuple = pickle.loads(rdata)
            user = user_code_tuple[0]
            code = user_code_tuple[1]
            verify(user, code)
            to_send = ACKNOWLEDGE_VERIFY_OPCODE
        except:
            to_send = ERROR_OPCODE + VERIFICATION_FAILED
    elif opcode == FORGOT_PASSWORD_OPCODE:
        try:
            email, code = forgot_pw(rdata.decode())
            send_msg_to_email(email, "Verification code","Code is: " + code.verify_code)
            to_send = FORGOT_PASSWORD_ACK
        except:
            to_send = ERROR_OPCODE + FORGOT_PASSWORD_FAILED
    elif opcode == FORGOT_PASSWORD_VERIFY_OPCODE:
        try:
            username, code = pickle.loads(rdata)
            forgot_pw_verify(username, code)
            to_send = ACKNOWLEDGE_LOGIN_OPCODE
        except:
            to_send = ERROR_OPCODE + FORGOT_PASSWORD_VERIFY_FAILED
    else:
        to_send = ERROR_OPCODE + UNCLEAR_INSTRUCTION
    return to_send


def get_key(soc):
    method = tcp.recv_by_size(soc)
    key = None
    if method == b'RSA':
        rsa_key = RSA.generate(2048)
        public_key = rsa_key.publickey().exportKey('DER')
        tcp.send_with_size(soc, public_key)
        cipher = Cipher_PKCS1_v1_5.new(rsa_key)
        key = cipher.decrypt(tcp.recv_by_size(soc), None)
    elif method == b'DFH':
        params_numbers = dh.DHParameterNumbers(P, G)
        parameters = params_numbers.parameters(default_backend())
        private_key = parameters.generate_private_key()
        public_key = private_key.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
        client_key = load_der_public_key(tcp.recv_by_size(soc), default_backend())
        tcp.send_with_size(soc, public_key)
        shared_key = private_key.exchange(client_key)
        key = HKDF(algorithm=hashes.SHA256(), length=16, salt=None, info=b'handshake data', ).derive(shared_key)
    return key


def recv_data(sock, key):
    d = tcp.recv_by_size(sock)
    data, iv = pickle.loads(d)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return bytes(unpad(cipher.decrypt(bytearray(data)), AES.block_size))


def send_data(sock, data, key):
    cipher = AES.new(key, AES.MODE_CBC)
    iv = cipher.iv
    to_send = pickle.dumps((cipher.encrypt(pad(data, AES.block_size)), iv))
    tcp.send_with_size(sock, to_send)


def handle_client(soc):

    key = get_key(soc)
    connected = True
    print("connection and thread made")
    while connected:
        try:
            data = recv_data(soc, key)
            if data != b'':
                to_send = handle_data(data)
                send_data(soc, to_send, key)
            else:
                connected = False
        except Exception as a:
            print(a)
            connected = False
    soc.close()
    print("Client disconnected and thread closed")


def main():
    # create socket
    serv = socket.socket()
    serv.bind(("0.0.0.0", 1234))
    serv.listen(5)

    cont = True
    threads = []
    while cont:
        c, a = serv.accept()
        trd = threading.Thread(target=handle_client, args=(c,))
        trd.start()
        threads.append(trd)

    # wait for all threads to end
    for i in threads:
        i.join()


if __name__ == '__main__':
    main()
