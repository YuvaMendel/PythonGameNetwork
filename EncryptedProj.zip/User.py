import os
import pickle
import random
import bcrypt
import hashlib
import time
import string
USERS_FILE_PATH = 'Resources\\users.pkl'
VERIFICATION_LENGTH = 6
VERIFY_TIME = 300


PEPER = b'RTF5d8'


class User:
    def __init__(self, username, email, password):
        self.email = email
        self.password = password
        self.username = username

    def __eq__(self, other):
        if type(self) == type(other):
            return self.username == other.username and self.email == other.email and self.password == other.password
        return False


class Verify:
    def __init__(self):
        self.verify_time = time.time()
        self.verify_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=VERIFICATION_LENGTH))
        self.is_verified = False

    def try_verify(self, code):
        if time.time() - self.verify_time < VERIFY_TIME and code == self.verify_code:
            self.is_verified = True
            return True
        return False


user_dict = {}
forgot_pw_dict = {}

if os.path.exists(USERS_FILE_PATH):
    with open(USERS_FILE_PATH, 'rb') as file:
        user_dict = pickle.load(file)


def forgot_pw_sign(username):
    global user_dict
    global forgot_pw_dict
    email = user_dict[username][0][0].email
    forgot_pw_dict[username] = Verify()
    return email, forgot_pw_dict[username]


def verify_fpw(username, code):
    global forgot_pw_dict
    global user_dict
    if forgot_pw_dict[username].try_verify(code):
        del forgot_pw_dict[username]
        user_dict[username][1].is_verified = True
        return True
    return False


def create_salted_user(user):
    salt = bcrypt.gensalt()
    return User(user.username, user.email, hashlib.sha256(user.password.encode() + salt + PEPER).hexdigest()), salt


def get_salted_user(user, salt):
    return User(user.username, user.email, hashlib.sha256(user.password.encode() + salt + PEPER).hexdigest())


def update_users_file():
    global user_dict
    with open(USERS_FILE_PATH, 'wb') as user_file:
        print(user_dict['1'][1].is_verified)
        pickle.dump(user_dict, user_file)


def save_user(user):
    global user_dict
    verification = Verify()
    user_dict[user.username] = create_salted_user(user), verification
    # update the users file
    update_users_file()
    return user, verification


def is_user_exist(user):
    global user_dict
    return user.username in user_dict.keys() and user_dict[user.username][0][0] == get_salted_user(user, user_dict[user.username][0][1]) and user_dict[user.username][1].is_verified


def remove_expired_code(user):
    global user_dict
    if user.username in user_dict.keys() and (time.time() - user_dict[user.username][1].verify_time) > VERIFY_TIME:
        del user_dict[user.username]


def can_save_user(user):
    global user_dict
    remove_expired_code(user)
    return not(user.username in user_dict.keys())


def verify(user, code):
    global user_dict
    if user.username in user_dict.keys():
        if user_dict[user.username][1].try_verify(code):
            update_users_file()
            return True

    return False
