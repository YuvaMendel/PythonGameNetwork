import pickle
import tkinter as tk
import socket
from User import User
import tcp
from tkinter.messagebox import showinfo
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5 as Cipher_PKCS1_v1_5
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import dh
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat, load_der_public_key
from cryptography.hazmat.backends import default_backend

SERVER_IP = '127.0.0.1'
SERVER_PORT = 1234

P = 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF
G = 2

# protocol opcodes
LOGIN_OPCODE = b'LOGN'
SIGNUP_OPCODE = b'SNUP'
ERROR_OPCODE = b'EROR'
ACKNOWLEDGE_LOGIN_OPCODE = b'ACKL'
ACKNOWLEDGE_SIGNUP_OPCODE = b'ACKS'
VERIFY_OPCODE = b'VRFY'
ACKNOWLEDGE_VERIFY_OPCODE = b'ACKV'
FORGOT_PASSWORD_OPCODE = b'FGPW'
FORGOT_PASSWORD_ACK = b'ACKP'
FORGOT_PASSWORD_VERIFY_OPCODE = b'FPWV'


# Error Codes
LOGIN_FAILED = b'001'
SIGNUP_FAILED = b'002'
UNCLEAR_INSTRUCTION = b'003'
VERIFICATION_FAILED = b'004'


def key_exchange_method():

    key_exchange = 'RSA'
    done = False

    def make_rsa():
        nonlocal key_exchange
        key_exchange = 'RSA'

    def make_dh():
        nonlocal key_exchange
        key_exchange = 'DFH'

    def pick():
        nonlocal key_exchange_root
        nonlocal done
        key_exchange_root.destroy()
        done = True
    key_exchange_root = tk.Tk()
    key_exchange_root.configure(background="yellow")
    key_exchange_root.minsize(400, 300)  # width, height
    rsa_button = tk.Button(key_exchange_root, text="RSA", command=make_rsa)
    rsa_button.pack()

    diffie_hellman_button = tk.Button(key_exchange_root, text="Diffie Hellman", command=make_dh)
    diffie_hellman_button.pack()

    pick_button = tk.Button(key_exchange_root, text="PICK", command=pick)
    pick_button.pack()
    key_exchange_root.mainloop()

    while not done:
        pass
    return key_exchange


def exchange_keys(soc_, method):
    tcp.send_with_size(soc_, method)
    if method == 'RSA':
        key_ = get_random_bytes(16)
        public_key = RSA.importKey(tcp.recv_by_size(soc_))
        cipher = Cipher_PKCS1_v1_5.new(public_key)
        to_send = cipher.encrypt(key_)
        print(to_send)
        tcp.send_with_size(soc_, to_send)
    elif method == 'DFH':
        params_numbers = dh.DHParameterNumbers(P, G)
        parameters = params_numbers.parameters(default_backend())
        private_key = parameters.generate_private_key()
        public_key = private_key.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
        tcp.send_with_size(soc_, public_key)
        server_key = load_der_public_key(tcp.recv_by_size(soc_), default_backend())
        shared_key = private_key.exchange(server_key)
        key_ = HKDF(algorithm=hashes.SHA256(),length=16,salt=None,info=b'handshake data',).derive(shared_key)
    else:
        raise Exception("Stupid")
    return key_


def create_connection():
    soc_ = socket.socket()
    soc_.connect((SERVER_IP, SERVER_PORT))
    key_exchange = key_exchange_method()
    key_ = exchange_keys(soc_, key_exchange)
    return soc_, key_


soc, key = create_connection()
root = tk.Tk()


def recv_data(sock):
    global key
    data, iv = pickle.loads(tcp.recv_by_size(sock))
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return bytes(unpad(cipher.decrypt(bytearray(data)), AES.block_size))


def send_data(sock, data):
    global key
    cipher = AES.new(key, AES.MODE_CBC)
    iv = cipher.iv
    to_send = pickle.dumps((cipher.encrypt(pad(data, AES.block_size)), iv))
    tcp.send_with_size(sock, to_send)


def forgot_pw_screen():
    def forgot_pw():
        send_data(soc,FORGOT_PASSWORD_OPCODE + username.get().encode())
        rdata = recv_data(soc)
        if handle_response(rdata):
            forgot_pw_vscreen()

    def forgot_pw_vscreen():
        def verify_code(un, cod):
            data = pickle.dumps((un, cod))
            send_data(soc,FORGOT_PASSWORD_VERIFY_OPCODE + data)
            rdata = recv_data(soc)
            if handle_response(rdata):
                forgot_pw_verify_root.destroy()
                forgot_pw_root.destroy()
        forgot_pw_verify_root = tk.Toplevel(forgot_pw_root)
        forgot_pw_verify_root.title("Verify")
        forgot_pw_verify_root.configure(background="green")
        forgot_pw_verify_root.minsize(400, 300)  # width, height

        code = tk.StringVar()
        code_label = tk.Label(forgot_pw_verify_root, text="Username:")
        code_label.pack()

        code_entry = tk.Entry(forgot_pw_verify_root, textvariable=code)
        code_entry.pack()

        code_button = tk.Button(forgot_pw_verify_root, text="Verify", command=lambda : verify_code(username.get(), code.get()))
        code_button.pack()
        forgot_pw_verify_root.mainloop()

    forgot_pw_root = tk.Toplevel(root)
    forgot_pw_root.title("Forgot Password")
    forgot_pw_root.configure(background="green")
    forgot_pw_root.minsize(400, 300)  # width, height

    username = tk.StringVar()
    username_label = tk.Label(forgot_pw_root, text="Username:")
    username_label.pack()

    username_entry = tk.Entry(forgot_pw_root, textvariable=username)
    username_entry.pack()

    forgot_pw = tk.Button(forgot_pw_root, text="GET CODE", command=forgot_pw)
    forgot_pw.pack()
    forgot_pw_root.mainloop()


def handle_response(data):
    protocol_opcode = data[:4]
    if protocol_opcode == ACKNOWLEDGE_LOGIN_OPCODE:
        showinfo(
            title='LOGIN',
            message= "Logged in successfully"
        )
    if protocol_opcode == ACKNOWLEDGE_SIGNUP_OPCODE:
        return True
    if protocol_opcode == ACKNOWLEDGE_VERIFY_OPCODE:
        showinfo(
            title='Verify',
            message="Verified"
        )
    if protocol_opcode == ERROR_OPCODE:
        showinfo(
            title='ERROR',
            message="error"
        )
        return False
    return True


def sign_up_screen():
    def sign_up():
        global soc
        if confirm_password.get() == password.get() and password.get() != '' and email.get() != '':

            if username.get() != '':
                login_user = User(username.get(), email.get(), password.get())
            else:
                login_user = User(email.get(), email.get(), password.get())
            pickled_user = pickle.dumps(login_user)
            send_data(soc, SIGNUP_OPCODE + pickled_user)
            rdata = recv_data(soc)
            if handle_response(rdata):
                two_step_auth_screen(login_user)

    def two_step_auth_screen(user):
        def authenticate(user_to_auth):
            pickled_data = pickle.dumps((user_to_auth, code.get()))
            send_data(soc, VERIFY_OPCODE + pickled_data)
            rdata = recv_data(soc)
            handle_response(rdata)
            two_step_auth_root.destroy()
            sign_up_root.destroy()
        code = tk.StringVar()
        two_step_auth_root = tk.Toplevel(sign_up_root)
        two_step_auth_root.title("2 step authentication")
        two_step_auth_root.configure(background="green")
        two_step_auth_root.minsize(400, 300)  # width, height

        verify_txt = tk.Label(two_step_auth_root, text="Verification Code:")
        verify_txt.pack()

        verify_entry = tk.Entry(two_step_auth_root, textvariable=code)
        verify_entry.pack()

        verify_btn = tk.Button(two_step_auth_root, text="Verify", command=lambda: authenticate(user))
        verify_btn.pack()

        two_step_auth_root.mainloop()

    sign_up_root = tk.Toplevel(root)
    sign_up_root.title("Sign Up")
    sign_up_root.configure(background="green")
    sign_up_root.minsize(400, 300)  # width, height

    username = tk.StringVar()
    password = tk.StringVar()
    email = tk.StringVar()
    confirm_password = tk.StringVar()

    username_label = tk.Label(sign_up_root, text="Username:")
    username_label.pack()

    username_entry = tk.Entry(sign_up_root, textvariable=username)
    username_entry.pack()

    pw_label = tk.Label(sign_up_root,text="Password:")
    pw_label.pack()

    pw_entry = tk.Entry(sign_up_root, show='*', textvariable=password)
    pw_entry.pack()

    cpw_label = tk.Label(sign_up_root, text="Confirm Password:")
    cpw_label.pack()

    cpw_entry = tk.Entry(sign_up_root, show='*', textvariable=confirm_password)
    cpw_entry.pack()

    email_label = tk.Label(sign_up_root, text="Email:")
    email_label.pack()

    email_entry = tk.Entry(sign_up_root, textvariable=email)
    email_entry.pack()

    signup_button = tk.Button(sign_up_root, text="Sign Up", command=sign_up)
    signup_button.pack()
    sign_up_root.mainloop()


def main():
    def login():
        if password.get() != '' and email.get() != '':
            global soc
            if username.get() != '':
                login_user = User(username.get(), email.get(), password.get())
            else:
                login_user = User(email.get(), email.get(), password.get())
            pickled_user = pickle.dumps(login_user)
            send_data(soc, LOGIN_OPCODE + pickled_user)
            rdata = recv_data(soc)
            handle_response(rdata)

    global root

    root.title("Login")
    root.configure(background="yellow")
    root.minsize(400, 300)  # width, height

    username = tk.StringVar()
    password = tk.StringVar()
    email = tk.StringVar()

    username_label = tk.Label(text="Username:")
    username_label.pack()

    username_entry = tk.Entry(root, textvariable=username)
    username_entry.pack()

    pw_label = tk.Label(text="Password:")
    pw_label.pack()

    pw_entry = tk.Entry(root, show='*', textvariable=password)
    pw_entry.pack()

    email_label = tk.Label(text="Email:")
    email_label.pack()

    email_entry = tk.Entry(root, textvariable=email)
    email_entry.pack()

    login_button = tk.Button(root, text="login", command=login)
    login_button.pack()

    fp_button = tk.Button(root, text="Forgot Password", command=forgot_pw_screen)
    fp_button.pack()

    signup_button = tk.Button(root, text="Sign Up", command=sign_up_screen)
    signup_button.pack()
    root.mainloop()


if __name__ == '__main__':
    main()
